<?php
/*
Template Name: Flexible Layout
*/
?>

<?php print get_template_component('HTML'); ?>
<?php print get_template_component('Page'); ?>
<?php print get_template_component('SiteHeader'); ?>
<?php print get_template_component('HeroHeader'); ?>

<?php print get_template_layout('FlexibleLayout'); ?>

<?php print get_template_component('SiteFooter'); ?>
<?php print get_template_component('Page', 'end'); ?>
<?php print get_template_component('HTML', 'end'); ?>