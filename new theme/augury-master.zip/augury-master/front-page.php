<?php print get_template_component('HTML'); ?>
<?php print get_template_component('Page'); ?>
<?php print get_template_component('SiteHeader'); ?>


<?php print get_template_component('HeroHome'); ?>

<?php print get_template_component('NewFooter'); ?>
<?php print get_template_component('Page', 'end'); ?>
<?php print get_template_component('HTML', 'end'); ?>