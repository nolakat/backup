<?php print get_template_component('SiteFooter'); ?>
<?php print get_template_component('Page', 'end'); ?>
<?php print get_template_component('HTML', 'end'); ?>