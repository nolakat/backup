<?php
/*
Template Name: Solutions
*/
?>


<?php print get_template_component('HTML'); ?>
<?php print get_template_component('Page'); ?>
<?php print get_template_component('SiteHeader'); ?>
<?php print get_template_component('HeroSplit'); ?>
<?php print get_template_component('NewFooter'); ?>

<?php print get_template_layout('FlexibleLayout'); ?>




<?php print get_template_component('Page', 'end'); ?>

<?php print get_template_component('HTML', 'end'); ?>

