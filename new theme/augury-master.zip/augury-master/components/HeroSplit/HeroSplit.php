<?php 

if (!isset($post_id)) {
    $post_id = get_the_id();
}

$titleTop = get_field('hero_header_title', $post_id);
if ($title === NULL || $title === "") {
    $title = get_the_title($post_id);
}

$titleBottom = get_field('hero_header_title_bottom', $post_id);
if ($title === NULL || $title === "") {
    $title = get_the_title($post_id);
}


$subtitle = get_field('hero_header_subtitle', $post_id);

$img = get_field('hero_header_image', $post_id);
if ($img === NULL) {
    $img = "";
} else {
    $img = $img["url"];
}

if ($size_class !== "disabled") { ?>

    <header class="Header SplitHeader" style="background-image: url(<?php echo $img ?>);">
    <div class="SplitHeader--overlay"></div>
            <div class="SplitHeader--row">
                <h5 class="Header--subtitle"><?php echo $subtitle; ?></h5>
                <h1 class="Header-title"><?php echo $titleTop; ?></h1>
                <p class="Header-content"><?php the_field("hero_header_content", $post_id); ?></p>
            </div>
            <div class="SplitHeader--row">
                <div class="SplitHeader--divider-container">
                    <img src="<?php bloginfo('template_url'); ?>/components/HeroSplit/divider.svg">
                </div>
            </div>

            <div class="SplitHeader--row solid--bl">
            <h1 class="Header-title"><?php echo $titleBottom; ?></h1>
            <p class="Header-content"><?php the_field("hero_header_content_bottom", $post_id); ?></p>
            </div>
    </header>
<?php }