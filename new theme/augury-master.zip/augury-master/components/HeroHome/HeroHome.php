<?php 

if (!isset($post_id)) {
    $post_id = get_the_id();
}

$title = get_field('hero_header_title', $post_id);
if ($title === NULL || $title === "") {
    $title = get_the_title($post_id);
}

$img = get_field('hero_header_image', $post_id);
if ($img === NULL) {
    $img = "";
} else {
    $img = $img["url"];
}

$if_btn = get_field('if_header_button', $post_id);
$btn_msg = get_field('hero_button_text', $post_id);

$if_logo_row = get_field('if_logo_row', $post_id);


$background_class = get_field("hero_header_background_color", $post_id);
$logo_row_title = get_field("logo_row_title", $post_id);

if ($size_class !== "disabled") { ?>
    <header class="Header HeroHeader HeroHeader--<?php echo $background_class; ?>">
            <div class="HeroHeader-container">
                <h1 class="Header-title"><?php echo $title; ?></h1>
                <?php the_field("hero_header_content", $post_id); ?>

                <?php if ($if_btn): ?>
                    <button class="button Header--button">
                        <span><?php echo $btn_msg; ?> <i class="fas fa-arrow-down"></i></span>
                    </button>
                <?php endif ?>
            </div>
            
            <?php if($if_logo_row): ?>
            <div class="HeroHeader--logo_row">
                <h5 class="LogoRow--title"><?php the_field("logo_row_title")?></h5>

                <div class="LogoRow--container"><img src="http://dev-kate-test.pantheonsite.io/wp-content/uploads/2018/07/logo2.png"> </div>
                <div class="LogoRow--container"><img src="http://dev-kate-test.pantheonsite.io/wp-content/uploads/2018/07/logo2.png"> </div>
                <div class="LogoRow--container"><img src="http://dev-kate-test.pantheonsite.io/wp-content/uploads/2018/07/logo2.png"> </div>
                <div class="LogoRow--container"><img src="http://dev-kate-test.pantheonsite.io/wp-content/uploads/2018/07/logo2.png"> </div> 
            </div>
            <?php endif ?>
      
    </header>
<?php }