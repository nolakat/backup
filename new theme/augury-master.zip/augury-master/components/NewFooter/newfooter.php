<footer class="newfooter">
</footer>